(function() {
    "use strict";
    var analyticsUrl = "https://au.zepiccdn.com/zepic-sdk.js";
    var zepicConfig = {"identifyUrl":"https://events.myzepic.com/api/v1/26b859ee-40b1-4b40-934e-de65636a005e/resolve-identity","cubeId":"329209761611845632","formTracking":false,"dataCollectorUrl":"https://events.myzepic.com/api/v1/26b859ee-40b1-4b40-934e-de65636a005e/events","domains":[""]};

    var async = true;

    if (window.zepic !== undefined) {
        console.log("Zepic SDK already loaded. Trying to include it twice.");
        return;
    }

    function loadSdk() {
        window.zepic_config = zepicConfig;
        var script = document.createElement("script");
        script.src = analyticsUrl;
        script.async = async;
        if (document.head) {
            document.head.appendChild(script);
        } else if (document.body) {
            document.body.appendChild(script);
        } else {
            var scriptElement = document.getElementsByTagName("script")[0]
            scriptElement.parentNode.insertBefore(script, scriptElement);
        }
    }

    loadSdk();

})()