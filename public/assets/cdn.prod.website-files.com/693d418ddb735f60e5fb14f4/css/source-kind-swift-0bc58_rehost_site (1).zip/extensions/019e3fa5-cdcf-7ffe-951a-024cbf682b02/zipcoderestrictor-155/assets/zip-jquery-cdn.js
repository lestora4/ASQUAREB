/* ERROR FETCHING: Failed to fetch
   URL: https://cdn.shopify.com/extensions/019e3fa5-cdcf-7ffe-951a-024cbf682b02/zipcoderestrictor-155/assets/zip-jquery-cdn.js */