appURL = 'https://api-zip-remix.appjetty.com';
console.log('Zipcode Live CODE PUSHED AT 19 May, 15:20');
var is_valid_email = false;
const zipCodeContainer = '.ZipCodeRestrict';

function removeOldZipcodeDiv(){
	if($(zipCodeContainer).length > 0){
		$(zipCodeContainer).remove();
	}
}

function appendZipcodeDivHtml(){
	if($(zipCodeContainer).length > 0){
		$(zipCodeContainer).append(zipcode_html);
		is_divfound = true;
	}
}

function zipCodeScriptTag(){
	var is_valid_zipcode = 1;
	var is_divfound = false;  
	checkout_btn_selector = (checkout_btn_selector == '') ? 'checkout' : checkout_btn_selector;  
	add_to_cart_btn_selector = (add_to_cart_btn_selector == '') ? 'add' : add_to_cart_btn_selector;
	var warning_text= 'Please enter zipcode';
	const $addtocartbtn = $(`[name=${add_to_cart_btn_selector}]`);
	const $zipcodeInputBoxID = '#zipcode_text';

	if(parseInt(autodetected_customer_zipcode_status) && (localStorage.getItem("pincode_val") === null || localStorage.getItem("pincode_val") === undefined || localStorage.getItem("pincode_val").trim() === '' || localStorage.getItem("pincode_val") === 'null')){
		localStorage.setItem("pincode_val",customer_zipcode);
	}
	if(button_appearance == 'inline_form' && (selected_plan != 0 || (selected_plan == 0 && trial_mode == 1))){		
		if(template_name == 'product'){
			if (zip_global != '' && zip_global != 'all_prod'){
				$(zipCodeContainer).hide();
			}
			var zipcoderestrictor_product_div = '<div class="ZipCodeRestrict zipcode_product_page">'+zipcode_html+'</div>';
			console.log("222222",btn_app_product_page);
			if(btn_app_product_page == 'above_cart_btn'){
				// removeOldZipcodeDiv();				
				// add_to_cart_parent_depth != 0 ? $('form').find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).before(zipcoderestrictor_product_div) : $('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().before(zipcoderestrictor_product_div);
				// if($('form').find('[name="'+add_to_cart_btn_selector+'"]').length > 0){
				// 	is_divfound = true;			
				// }
				////////////////////////////////////////
				const $btns = $('form').find('[name*="' + add_to_cart_btn_selector + '"]');
				removeOldZipcodeDiv();
				console.log("3333333333");
				console.log($btns.length);
				if ($btns.length > 1) {
					var foundParentClass = false;
					var parentPDParray = ['product-information','product-details', 'custom-product-details', 'product-form__buttons'];
					$.each(parentPDParray, function (i, parentClass) {
						var $parent = $('.' + parentClass);
						if ($parent.length) {
							if ($parent.find('button[name="add"]').length > 0) {
								foundParentClass = true;
								if(add_to_cart_parent_depth != 0){
                                    $('.'+parentClass).find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).before(zipcoderestrictor_product_div)
                                }else{
                                    $('.'+parentClass).find('[name="'+add_to_cart_btn_selector+'"]').parent().before(zipcoderestrictor_product_div);
                                }
								// add_to_cart_parent_depth != 0 ? $('.'+parentPDParray).find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).before(zipcoderestrictor_product_div) : $('.'+parentPDParray).find('[name="'+add_to_cart_btn_selector+'"]').parent().before(zipcoderestrictor_product_div);
								return false;
							}
						}
					});
					if(!foundParentClass){
						add_to_cart_parent_depth != 0 ? $('form').find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).before(zipcoderestrictor_product_div) : $('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().before(zipcoderestrictor_product_div);
						console.log('not found classs in mensioned array');
					}
				} else {
					add_to_cart_parent_depth != 0 ? $('form').find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).before(zipcoderestrictor_product_div) : $('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().before(zipcoderestrictor_product_div);
				}
				if($('form').find('[name="'+add_to_cart_btn_selector+'"]').length > 0){
					is_divfound = true;			
				}
				////////////////////////////////////////
			}else if(btn_app_product_page == 'below_cart_btn'){	
				// removeOldZipcodeDiv();
				// add_to_cart_parent_depth != 0 ? $('form').find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).after(zipcoderestrictor_product_div) : $('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().after(zipcoderestrictor_product_div);
				// if($('form').find('[name="'+add_to_cart_btn_selector+'"]').length > 0){
				// 	is_divfound = true;
				// }
				////////////////////////////////////////
				const $btns = $('form').find('[name*="' + add_to_cart_btn_selector + '"]');
				removeOldZipcodeDiv();
				if ($btns.length > 1) {
					var foundParentClass = false;
					var parentPDParray = ['product-information','product-details', 'custom-product-details'];
					$.each(parentPDParray, function (i, parentClass) {
						var $parent = $('.' + parentClass);
						if ($parent.length) {
							if ($parent.find('button[name="add"]').length > 0) {
								foundParentClass = true;
								add_to_cart_parent_depth != 0 ? $('.'+parentPDParray).find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).after(zipcoderestrictor_product_div) : $('.'+parentPDParray).find('[name="'+add_to_cart_btn_selector+'"]').parent().after(zipcoderestrictor_product_div);
								return false;
							}
						}
					});
					if(!foundParentClass){
						add_to_cart_parent_depth != 0 ? $('form').find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).after(zipcoderestrictor_product_div) : $('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().after(zipcoderestrictor_product_div);
						console.log('not found classs in mensioned array');
					}
				} else {
					add_to_cart_parent_depth != 0 ? $('form').find('[name="'+add_to_cart_btn_selector+'"]').parents().eq(add_to_cart_parent_depth).after(zipcoderestrictor_product_div) : $('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().after(zipcoderestrictor_product_div);
				}
				if($('form').find('[name="'+add_to_cart_btn_selector+'"]').length > 0){
					is_divfound = true;
				}
				////////////////////////////////////////
			}else if(btn_app_product_page == 'prod_manual_integration'){
				if($('form').find(zipCodeContainer).length > 0){
					is_divfound = true;
					if($(zipCodeContainer).hasClass('zipcode_product_page')){
						$('.ZipCodeRestrict.zipcode_product_page').html('');
						appendZipcodeDivHtml();
					}else{
						appendZipcodeDivHtml();
					}
				}else{
					var appjetty_zipcode_form_id =  $('.zip-main-btn[name="'+add_to_cart_btn_selector+'"]').parents('form').attr('id');
					$('.ZipCodeRestrict[form_id="'+appjetty_zipcode_form_id+'"]').append(zipcode_html);
				}
			}else{
				removeOldZipcodeDiv();
			}
		}
		// don't remove this code start here....
		// if(domain == "myvegangreens.com"){
		// 	if(template_name == 'page'){
		// 		var zipcoderestrictor_product_div = '<div class="ZipCodeRestrict zipcode_product_page">'+zipcode_html+'</div>';
		// 		$('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().before(zipcoderestrictor_product_div);
		// 		if($('form').find('[name="'+add_to_cart_btn_selector+'"]').length > 0){
		// 			is_divfound = true;			
		// 		}
		// 	}
		// }
		// end here....
	}else if(button_appearance == 'zipcode_header_bar' && (selected_plan != 0 || (selected_plan == 0 && trial_mode == 1))){
		if($('.aj_zipcode_header').length > 0){
			$('.aj_zipcode_header').append(zipcode_html);
			is_divfound = true;
		}
	}else if(button_appearance == 'zipcode_global_popup' && (selected_plan != 0 || (selected_plan == 0 && trial_mode == 1))){
		if($('.zipcode_global_section').length > 0){
			$('.zipcode_global_section').append(popup_header_html);
			$('body').append(zipcode_html);
			is_divfound = true;
		}
		if($('.appjetty-zipcode-popup-msg').length > 0){
			if($('.zipcode_product_info').length == 0){
				$('.appjetty-zipcode-popup-msg').html(global_validation_html);
			}
		}else{
			if($('.zipcode_product_info').length == 0){
				$('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().before(global_validation_html);
			}
		}
		$('.close-popup').click(function(){
			$('.modal_popup').hide();
			localStorage.setItem("pincode_val",$($zipcodeInputBoxID).val());
			localStorage.setItem("zipcode_modal_popup",false);
			if($($zipcodeInputBoxID).val() == ''){
				$('#text-line1').html(upper_header_text);
				$('.check_zipcode').length == 0 ? $('#check_zipcode').html(header_lower_text) : $('.check_zipcode').html(header_lower_text)
			}
		});
		$($zipcodeInputBoxID).val() == '' ? $('.check-validation-msg').show() : $('.check-validation-msg').hide();
		$($zipcodeInputBoxID).on('input',function(){
			if($(this).val() == ''){
				$('.check-validation-msg').show();
			}
		});
		$(document).on('keydown', $zipcodeInputBoxID, function(e) {
			if (e.key === "Enter") {
				e.preventDefault();
				$('.zipcode_submit').click();
			}
		});
		$('.error_msg span img, .error_msg span span, .success_msg span img, .success_msg span span').css('cursor','pointer');
		$(document).on('click','#zipcode_modal_popup_icon,#zipcode_product_button,#nav-global-location-popover-link,.zipcode_global_section, .aj_change_zipcode, .success_msg span img, .success_msg span span, .error_msg span img, .error_msg span span, .check-validation-msg span',function(){
			$('.modal_popup').show();
		});
	}else if(selected_plan != 0 || (selected_plan == 0 && trial_mode == 1)){						
		if(modal_popup == 'popup_on_first_page'){
			$(zipCodeContainer).remove();
			$('body').append(zipcode_html);
			var zipcode_modal_popup = localStorage.getItem("zipcode_modal_popup");
			if(zipcode_modal_popup == 'false'){				
				$('.modal_popup').hide();				
				is_divfound = true;
			}else{
				if($(zipCodeContainer).length > 0){	 			
					hide_auto_showing_popup ? $('.modal_popup').hide() : $('.modal_popup').show();
					is_divfound = true;
				}
			}
						
			if(template_name == 'product'){
				if(zipcode_app_status == '1'){
					var zipcoderestrictor_modal_popup_div = '<p class="zipcode_product_info" style="font-size:'+popup_pre_prod_message_text_size+'px;">'+popup_pre_prod_message.replace('{%startlink%}','<a class="zipcode_product_button" href="javascript:void(0)" id="zipcode_product_button">').replace('{%endlink%}','</a>')+'</p>';
					if($('.appjetty-zipcode-popup-msg').length > 0){
						$('.appjetty-zipcode-popup-msg').html(zipcoderestrictor_modal_popup_div);
					}else{
						$('form').find('[name="'+add_to_cart_btn_selector+'"]').parent().before(zipcoderestrictor_modal_popup_div);
					}
					is_divfound = true;
				}
			}
			
			if(floating_icon == '1'){
				if (button_position == "bottom_right") {
					$(".set-icon").css({"right":'',"bottom":'',"left":'',"right":distance_from_right + 'px'});					
					var selectedClass = 'bottom-right';
				} else {
					$(".set-icon").css({"left": '', "bottom": '', "right":'', "left":distance_from_left + 'px'});					
					var selectedClass = 'bottom-left';
				}
				$(".set-icon").addClass(selectedClass);
				$("#zipcode_modal_popup_icon svg").css("height", icon_size + 'px');
				$(".set-icon .icon-circle svg").css("width", icon_size + 'px');
				$(".set-icon .icon-circle svg path").css('fill', icon_color);
				$(".set-icon .icon-circle").css({'background-color': button_bg_color, "margin": button_margin + 'px', "padding": button_padding + 'px', "width":"auto", "height":"auto"});
				$('.set-icon').css({"bottom": distance_from_bottom + 'px'});							
			}
			if(inline_header == '1'){
				$('.zipcode_header_section').append(header_html);
			}
		}

		$('.close-popup').click(function(){
			$('.modal_popup').hide();
			localStorage.setItem("zipcode_modal_popup",false);
		});

		$(document).on('click','#zipcode_modal_popup_icon,#zipcode_product_button,#nav-global-location-popover-link,.zipcode_global_section, .aj_change_zipcode',function(){
			$('.modal_popup').show();
		});

		$(document).on('keydown', $zipcodeInputBoxID, function(e) {
			if (e.key === "Enter") {
				e.preventDefault();
				$('.zipcode_submit').click();
			}
		});

		if (zipcode_check_compulsory_status == 1 && (localStorage.getItem("pincode_val") === null || localStorage.getItem("pincode_val") === undefined || localStorage.getItem("pincode_val").trim() === '' || localStorage.getItem("pincode_val") === 'null')) {
			$('.modal_popup').show();
			$('.aj-remove.close-popup').css('display','none');
		}
	}  

	if($('form').find(zipCodeContainer).length > 0){
		is_divfound = true;
	}else if($('#shopify-section-product-template').find(zipCodeContainer).length > 0){
		is_divfound = true;
	}else if($('#nt_content').find(zipCodeContainer).length > 0){
		is_divfound = true;
	}else if($('.ZipCodeRestrict.zipcode-outside').length > 0){
		is_divfound = true;
	}else{
		console.log('div not found.....');
	}

	if(is_divfound && (selected_plan != 0 || (selected_plan == 0 && trial_mode == 1))){ 
		if(zipcode_app_status == '1'){
			if(zip_prod_config_status != 'all_prod'){
				$.ajax({
					type : 'post',
					url  : appURL+'/appjetty-zipcode-widget',
					data  : { 'pid' : product_id,'pincode_val' : pincode_val,'collection_id' : zip_collection_id,'domain'
					:domain },
					dataType : 'json',
					success:function(resp){
						product_visiblity=resp.visibility_status;
						if(resp.visibility_status){
							if(button_appearance == 'inline_form'){
								$(zipCodeContainer).show();
							}
							if(modal_popup == 'none'){
								$('.modal_popup').hide();
							}
						}else{
							if(button_appearance != 'zipcode_global_popup'){
								$(zipCodeContainer).html('').addClass('zipcode_widget_disabled');
							}
							if(button_appearance == 'zipcode_global_popup' && waiting_list_btn_status == '1'){
								$('.aj_waiting_list').hide();
							}
							removeCheckButtonAction(button_text);
							$(zipCodeContainer).hide();
							$addtocartbtn.attr("disabled", false);
							is_valid_zipcode = 0;
						}
					},
					error:function(resp){
						removeCheckButtonAction(button_text);
						$addtocartbtn.attr("disabled", false);
						is_valid_zipcode = 0;
					}
				});
			}

			var pincode_val =localStorage.getItem("pincode_val");
			check_validation(pincode_val);
			if(pincode_val != 'null'){
				$($zipcodeInputBoxID).val(pincode_val);
			}
			
			$(document).on('click','.zipcode_submit',function(event){		  
				if(credit_status){
					event.preventDefault();
					$(this).text('Checking...');
					$(this).css({"opacity": "0.4", "cursor": "not-allowed"});
					$('.zipcode_submit').prop( "disabled", false );
					var pincode_val = $($zipcodeInputBoxID).val().trim();
					function containsSpecialChars(str) {
						const specialChars = /[`!@#$%^&*()_+=\[\]{};':"\\|,.<>\/?~]/;
						return specialChars.test(pincode_val);
					}
					if(typeof product_id  !="undefined"){
						if(containsSpecialChars(pincode_val)) {
							$('.validation_msg .success_msg').css('display','none');
							$('.validation_msg .error_msg span').css('display','none');
							$('.validation_msg .error_msg').css('display', 'block').append("<span class='test' style='color:#000'>Only alphabetic and numeric values allowed</span>");
							removeCheckButtonAction(button_text);
						}else{
							$('.test').remove();
							if(button_appearance != 'zipcode_global_popup'){
								$('.validation_msg .error_msg span').css('display','block');
							}
							check_validation(pincode_val); 
						}
					}
					if($($zipcodeInputBoxID).val().trim() == ''){
						$('.empty_val_error').css('display','block');
						$($zipcodeInputBoxID).css({"border": "2px solid #f00", "outline-color": "red"});
						$('.zipcode_validation').css('padding-bottom','2px');
						$('.validation_msg .message').hide();
					}else{
						$('.empty_val_error').hide();
						$($zipcodeInputBoxID).css({'outline-color':''});
						$('.zipcode_validation').css('padding-bottom','10px');
					}
				}else{
					console.log('Credit finsished');
				}		
			});
		
			function check_validation(pincode_val){
				is_same_pincode = pincode_val == localStorage.getItem("pincode_val") ? 1 : 0;
				if(localStorage.getItem("pincode_val") != null || localStorage.getItem("pincode_val") != 'null'){
					localStorage.setItem("pincode_val",pincode_val);
					if (zipcode_check_compulsory_status == 1 && localStorage.getItem("pincode_val") !== null && localStorage.getItem("pincode_val") !== undefined && localStorage.getItem("pincode_val").trim() !== '' && localStorage.getItem("pincode_val") !== 'null') {
						$('.aj-remove.close-popup').css('display','block');
					}
				}
				
				$.ajax({
					type : 'post',
					url  : appURL+'/appjetty-zipcode',
					data  : { 'pid' : product_id,'pincode_val' : pincode_val,'collection_id' : zip_collection_id,'domain':domain, 'pincode_status':is_same_pincode },
					dataType : 'json',
					success:function(resp){	
						// may flower client customizatio - please do not remove this code
						jQuery.getJSON('/cart.js', function(cart) { // get city name set value in localstorage city field.
								localStorage.setItem("appjetty_zipcity",resp.zip_city);
						});
						// end customization
						if(resp.credits <= '0'){
							console.log('Credit finsished');
							$('.zipcode_global_section, .ZipCodeRestrict, .aj_waiting_list').hide();
							return "Opps ! You have used all your credits";
						}
						if(zipcode_logs_status == 1 && $($zipcodeInputBoxID).val().trim() != ''){
							let userAgentString =  navigator.userAgent; 
						
							if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgentString)){
								device_type = "Mobile";
							}else{
								device_type = "Desktop";  
							}
							let region;  
							$.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
								var countryCode = (resp && resp.country) ? resp.country : "us";
								region = resp.region;
							});
							const currentZipcode = $($zipcodeInputBoxID).val();
							if (currentZipcode !== localStorage.getItem('previousZipcode')) {
								localStorage.setItem('previousZipcode',currentZipcode);
								$.ajax({
									type: 'post',
									url: appURL + '/zipcode-logs',
									data: {
										'pincode_val': pincode_val,
										'domain': domain,
										'response': resp,
										'product_id' : product_id,
										'product_name' : product_name,
										'button_appearance': button_appearance,
										'device': device_type,
										'region':region
									},
									dataType: 'json',
									success: function(resp) {
										console.log('Second AJAX call successful',resp);
									},
									error: function(resp) {
										console.log('Second AJAX call error', resp);
									}
								});
							}
						}
						if(restriction_btn_status == 1){
							if($(zipCodeContainer).hasClass('zipcode_widget_disabled')){
								$addtocartbtn.removeAttr("disabled");
								is_valid_zipcode = 1;
							}else{
								console.log("in a else-----");
								if($('.product-form__payment-container').hasClass('custom-pdp-action-btn')){
									$('.custom-pdp-action-btn').addClass('custom-disabled-btn');
								}else{
									$addtocartbtn.attr("disabled", true);
								}
								is_valid_zipcode = 0;				
							}
						}else{
							$addtocartbtn.removeAttr("disabled");
							is_valid_zipcode = 1;
						}
						
						if(global_restriction_btn_status == 1){
							$addtocartbtn.removeAttr("disabled");
							is_valid_zipcode = 1;
						}

						if(enable_checkout_button == 1){						
							$('[name="'+checkout_btn_selector+'"]').attr("disabled", true);
							var disable_checkout_button_txt = '<p class="zipcode_disable_checkout_btn_info">Please enter valid pincode to enable checkout button</p>';
							if($('.zipcode_checkout_info').length > 0){
                            	$('.zipcode_checkout_info').append(disable_checkout_button_txt);
							} else {
								$('form').find('[name*="'+checkout_btn_selector+'"]').parent().before(disable_checkout_button_txt);
							}
							if(zip_prod_config_status != 'all_prod'){
								$('[name*="'+checkout_btn_selector+'"]').removeAttr("disabled");
							}
						}else{
							$('[name*="'+checkout_btn_selector+'"]').removeAttr("disabled");
							$('.zipcode_disable_checkout_btn_info').remove();
							$('.zipcode_checkout_btn_info').remove();
						}
												
						if(!$(zipCodeContainer).hasClass('zipcode_widget_disabled')){
							if(resp.is_valid_pincode == 1){
								if(button_appearance == 'zipcode_header_bar'){
									if($($zipcodeInputBoxID).val().trim() != ''){
										$('.validation_msg .success_msg,.validation_msg .estimation_msg, .aj_auto_detect_location').css('display','block');
										if(resp.estimated_day != '' ){
											if(resp.estimated_day != null){
												$('.estimated_days').text(estimation_msg.replace('[est_days]', resp.estimated_day));
											}else{
												$('.estimation_msg').hide();
											}
										}else{
											$('.estimation_msg').hide();
										}
										$('.validation_msg .error_msg,.validation_msg .not_valid_error_msg').hide();
										if(resp.is_cart_disable == 1){
											$("[name="+resp.add_to_cart_btn_selector+"]").removeAttr("disabled");
											is_valid_zipcode = 1;
										}		
										if(waiting_list_btn_status == 1){				
											$('.customer_email, .customer_phone, .waiting_list_submit').hide();
											$(".zipcodecheck_area").slideDown();									
										}
										$addtocartbtn.removeAttr("title",warning_text);
																			
										if(enable_checkout_button == 1){
											$('[name*="'+checkout_btn_selector+'"]').removeAttr("disabled");
											$('.zipcode_checkout_btn_info').remove();
											$('.zipcode_disable_checkout_btn_info').remove();
										}
										setTimeout(function(){
											$('.zipcodecheck_area').slideUp();
										},1);
									}else{
										$('.validation_msg .message').hide();
										$addtocartbtn.attr("disabled", true); // For Add to cart Restrictions and Globally Add to cart Restrictions button enabled. If zipcode is not entered and on page load checking - client name : lbindia, client id : 530 - changes date 20-07-2022
									}
								}else if(button_appearance == 'zipcode_global_popup'){
									if($('.zipcode_global_section').length > 0){
										if(template_name == 'product'){
											if(zipcode_app_status == '1'){
												if($($zipcodeInputBoxID).val().trim() != ''){
													$('.check-validation-msg').hide();
													$('.aj_validation_msg').text(delivery_success_text.replace('[aj_pincode]',localStorage.getItem('pincode_val')));
													const displayType = $('.square_box_layout_messages').length === 1 ? 'flex' : 'block';
													$('.validation_msg .success_msg, .validation_msg .estimation_msg, .validation_msg .aj_exchange_msg, .validation_msg .aj_cod_msg, .aj_auto_detect_location').css('display', displayType);
													if (resp.estimated_day) {
														$('.estimated_days').text(estimation_msg.replace('[est_days]', resp.estimated_day));
													} else {
														$('.estimation_msg').hide();
													}
													if(resp.exchange_and_return){
														$('.aj_return_days').text(exchange_and_return_msg.replace('[return_and_exchange_days]', resp.exchange_and_return));
													}else{
														$('.aj_exchange_msg').hide();
													}
													resp.cash_on_delivery ? $('.aj_cod_msg').show() : $('.aj_cod_msg').hide();
													$('.validation_msg .error_msg,.validation_msg .not_valid_error_msg').hide();
													if(resp.is_cart_disable == 1){
														$("[name="+resp.add_to_cart_btn_selector+"]").removeAttr("disabled");
														is_valid_zipcode = 1;
													}		
													if(waiting_list_btn_status == 1){				
														$('.waiting_list_msg, .customer_email, .customer_phone, .waiting_list_submit, .try_zipcode').hide();									
													}
													$addtocartbtn.removeAttr("title",warning_text);
																						
													if(enable_checkout_button == 1){
														$('[name*="'+checkout_btn_selector+'"]').removeAttr("disabled");
														$('.zipcode_checkout_btn_info').remove();
														$('.zipcode_disable_checkout_btn_info').remove();
													}
													$('.modal_popup').hide();
												}else{
													$('.check-validation-msg').show();
													$('.validation_msg .message').hide();
													$addtocartbtn.attr("disabled", true);
												}
											}
										}
										if($($zipcodeInputBoxID).val().trim() != ''){
											$('#text-line1').html(resp.header_text_after_zipcode);
											$('.check_zipcode').length == 0 ? $('#check_zipcode').html(pincode_val) : $('.check_zipcode').html(pincode_val)
										}
									}
								}else{
									if($($zipcodeInputBoxID).val().trim() != ''){
										$('.success_message_color_prev').text(delivery_success_text.replace('[aj_pincode]',localStorage.getItem('pincode_val')));
										if($('.square_box_layout_messages').length == 1){
											$('.validation_msg .success_msg,.validation_msg .estimation_msg, .validation_msg .aj_exchange_msg, .validation_msg .aj_cod_msg, .aj_auto_detect_location').css('display','flex'); //changesJignesh
										}else{
											$('.validation_msg .success_msg,.validation_msg .estimation_msg, .validation_msg .aj_exchange_msg, .validation_msg .aj_cod_msg, .aj_auto_detect_location').css('display','block'); //changesJignesh
										}
										if(resp.estimated_day){
											$('.estimated_days').text(estimation_msg.replace('[est_days]', resp.estimated_day));
										}else{
											$('.estimation_msg').hide();
										}
										if(resp.exchange_and_return != '' ){
											if(resp.exchange_and_return != null){
												if(resp.exchange_and_return === '0 days'){
													$('.aj_return_days').text('Return is not available');
												}else{
													$('.aj_return_days').text(exchange_and_return_msg.replace('[return_and_exchange_days]', resp.exchange_and_return));
												}
											}else{
												$('.aj_exchange_msg').hide();
											}
										}else{
											$('.aj_exchange_msg').hide();
										}
										resp.cash_on_delivery ? $('.aj_cod_msg').show() : $('.aj_cod_msg').hide();
										$('.validation_msg .error_msg,.validation_msg .not_valid_error_msg').hide();
										if(resp.is_cart_disable == 1){
											if($('.custom-pdp-action-btn').hasClass('custom-disabled-btn')){
												$('.custom-pdp-action-btn').removeClass('custom-disabled-btn');
											}else{
												$("[name="+resp.add_to_cart_btn_selector+"]").removeAttr("disabled");
											}
											console.log('yes it is a valid zipcode.... remove the disabled.......');
											is_valid_zipcode = 1;
										}		
										if(waiting_list_btn_status == 1){				
											$('.customer_email, .customer_phone, .waiting_list_submit').hide();
											$(".zipcodecheck_area").slideDown();									
										}
										if(modal_popup == 'popup_on_first_page'){								
											if($('.appjetty-zipcode-popup-msg').length > 0){
												$('.appjetty-zipcode-popup-msg').html(popup_post_prod_message.replace('{%startlink%}','<a class="zipcode_product_button" href="javascript:void(0)" id="zipcode_product_button">').replace('{%endlink%}','</a>'));
											}else{
												$(".zipcode_product_info").html(popup_post_prod_message.replace('{%startlink%}','<a class="zipcode_product_button" href="javascript:void(0)" id="zipcode_product_button">').replace('{%endlink%}','</a>'));
											}
										}
										$addtocartbtn.removeAttr("title",warning_text);
																		
										if(enable_checkout_button == 1){
											$('[name*="'+checkout_btn_selector+'"]').removeAttr("disabled");
											$('.zipcode_checkout_btn_info').remove();
											$('.zipcode_disable_checkout_btn_info').remove();
										}

										if(inline_header == '1'){
											$('#text-line1').html(resp.header_text_after_zipcode);
											$('.check_zipcode').length == 0 ? $('#check_zipcode').html(pincode_val) : $('.check_zipcode').html(pincode_val)
										}
									}else{
										$('.validation_msg .message').hide();
										$addtocartbtn.attr("disabled", true);
									}
									if (restrict_store_entry_status == 1 && localStorage.getItem('zipcode_modal_popup') == 'false') {
										$('.modal_popup').hide();
										$('.aj-remove.close-popup').css('display','block');
									}else if(restrict_store_entry_status == 1){
										$('.modal_popup').show();
										$('.aj-remove.close-popup').css('display','block');
									}
								}
								localStorage.setItem("is_enabled_checkout",1);
							}else{
								if(button_appearance == 'zipcode_header_bar'){
									if($($zipcodeInputBoxID).val().trim() != ''){
										setTimeout(function(){
											if(waiting_list_btn_status == 1){
												$(".block_label_text, .aj-input-location-container").slideUp();
											}else{
												$('.zipcodecheck_area').slideUp();
											}
										},1);
										if(resp.is_match_format == 0){
											$('.validation_msg .not_valid_error_msg').css('display','block');
										}else{
											$('.validation_msg .error_msg').css('display','block');
										}
										if(resp.is_cart_disable == 1){ 									
											$("[name="+resp.add_to_cart_btn_selector+"]").attr("disabled", true);
											is_valid_zipcode = 0;
										}
										if(waiting_list_btn_status == 1){
											$(".block_label_text, .aj-input-location-container").slideUp();
											$('.customer_email, .customer_phone, .waiting_list_submit, #change_zipcode, .waiting_list_msg, .hidden-choose-code').show();					
											$('.error_msg').hide();
											$('.aj_auto_detect_location').hide();
										}
										if($($zipcodeInputBoxID).val().trim() == ''){							
											$addtocartbtn.attr("title",warning_text);
										}else{
											$addtocartbtn.removeAttr("title",warning_text);
										}
										if(enable_checkout_button == 1){									
											$('[name*="'+checkout_btn_selector+'"]').attr("disabled", true);
											var enable_checkout_button_txt = '<p class="zipcode_checkout_btn_info">'+checkout_btn_txt.replace('{zipcode}',pincode_val)+'</p>';
											// $('form').find('[name*="'+checkout_btn_selector+'"]').parent().before(enable_checkout_button_txt);
											$('[name*="'+checkout_btn_selector+'"]').parent().before(enable_checkout_button_txt);
											$('.zipcode_disable_checkout_btn_info').remove();
										}
									}
								}else if(button_appearance == 'zipcode_global_popup'){
									if($('.zipcode_global_section').length > 0){
										$('.validation_msg .message').hide();
										if($($zipcodeInputBoxID).val().trim() != ''){
											$('.aj_validation_msg').text(delivery_unsuccess_text.replace('[aj_pincode]',localStorage.getItem('pincode_val')));
											if(resp.is_cart_disable == 1){ 
												$addtocartbtn.attr("disabled", true);
											}
											if(resp.is_match_format == 0){
												$('.validation_msg .not_valid_error_msg').css('display','block');
											}else{ 
												$('.validation_msg .error_msg').css('display','block');
											}
											if(resp.is_cart_disable == 1){ 									
												$("[name="+resp.add_to_cart_btn_selector+"]").attr("disabled", true);
												is_valid_zipcode = 0;
											}
																			
											if(waiting_list_btn_status == 1){
												$('.customer_email, .customer_phone, .waiting_list_submit, #aj_change_zipcode, .waiting_list_msg, .hidden-choose-code, .try_zipcode').show();
												$('.aj_auto_detect_location').hide();
											}
											if($($zipcodeInputBoxID).val().trim() == ''){							
												$addtocartbtn.attr("title",warning_text);
											}else{
												$addtocartbtn.removeAttr("title",warning_text);
											}									
											if(enable_checkout_button == 1){									
												$('[name*="'+checkout_btn_selector+'"]').attr("disabled", true);
												var enable_checkout_button_txt = '<p class="zipcode_checkout_btn_info">'+checkout_btn_txt.replace('{zipcode}',pincode_val)+'</p>';
												// $('form').find('[name*="'+checkout_btn_selector+'"]').parent().before(enable_checkout_button_txt);
												$('[name*="'+checkout_btn_selector+'"]').parent().before(enable_checkout_button_txt);
												$('.zipcode_disable_checkout_btn_info').remove();
											}
											
											$('#text-line1').html(resp.header_text_after_zipcode);
											$('.check_zipcode').length == 0 ? $('#check_zipcode').html(localStorage.getItem('pincode_val')) : $('.check_zipcode').html(localStorage.getItem('pincode_val'));
											$('.check-validation-msg').hide();
											$('.modal_popup').hide();
										}else{
											$('.aj_waiting_list').hide();
											$('.check-validation-msg').show();
											$('#text-line1').html(resp.upper_header_text);
											$('.check_zipcode').length == 0 ? $('#check_zipcode').html(resp.header_lower_text) : $('.check_zipcode').html(resp.header_lower_text);
										}
									}
								}else{
									$('.validation_msg .message').hide();
									if($($zipcodeInputBoxID).val().trim() != ''){
										$('.unsuccess_message_color_prev').text(delivery_unsuccess_text.replace('[aj_pincode]',localStorage.getItem('pincode_val')));
										if(resp.is_cart_disable == 1){ 
											if($('.product-form__payment-container').hasClass('custom-pdp-action-btn')){
												$('.custom-pdp-action-btn').addClass('custom-disabled-btn');
											}else{
												$addtocartbtn.attr("disabled", true);
											}
										}
										
										if(resp.is_match_format == 0){
											$('.validation_msg .not_valid_error_msg').css('display','block');
										}else{ 
											$('.validation_msg .error_msg').css('display','block');
										}
										if(resp.is_cart_disable == 1){ 		
											if($('.product-form__payment-container').hasClass('custom-pdp-action-btn')){
												$('.custom-pdp-action-btn').addClass('custom-disabled-btn');
											}else{
												$("[name="+resp.add_to_cart_btn_selector+"]").attr("disabled", true);
											}
											is_valid_zipcode = 0;
										}
																		
										if(waiting_list_btn_status == 1){
											$('.customer_email, .customer_phone, .waiting_list_submit, #change_zipcode, .waiting_list_msg, .hidden-choose-code').show();					
											$(".zipcodecheck_area").slideUp();
											$('.error_msg').hide();
											$('.aj_auto_detect_location').hide();
										}
										if($($zipcodeInputBoxID).val().trim() == ''){							
											$addtocartbtn.attr("title",warning_text);
										}else{
											$addtocartbtn.removeAttr("title",warning_text);
										}
										if(modal_popup == 'popup_on_first_page'){
											if($('.appjetty-zipcode-popup-msg').length > 0){
												$('.appjetty-zipcode-popup-msg').html(popup_pre_prod_message.replace('{%startlink%}','<a class="zipcode_product_button" href="javascript:void(0)" id="zipcode_product_button">').replace('{%endlink%}','</a>'));
											}else{
												$(".zipcode_product_info").html(popup_pre_prod_message.replace('{%startlink%}','<a class="zipcode_product_button" href="javascript:void(0)" id="zipcode_product_button">').replace('{%endlink%}','</a>'));
											}
										}
										
										if(enable_checkout_button == 1){									
											$('[name*="'+checkout_btn_selector+'"]').attr("disabled", true);
											var enable_checkout_button_txt = '<p class="zipcode_checkout_btn_info">'+checkout_btn_txt.replace('{zipcode}',pincode_val)+'</p>';
											// $('form').find('[name*="'+checkout_btn_selector+'"]').parent().before(enable_checkout_button_txt);
											$('[name*="'+checkout_btn_selector+'"]').parent().before(enable_checkout_button_txt);
											$('.zipcode_disable_checkout_btn_info').remove();
										}
										
										if(inline_header == '1'){
											$('#text-line1').html(resp.upper_header_text);
											$('.check_zipcode').length == 0 ? $('#check_zipcode').html(resp.header_lower_text) : $('.check_zipcode').html(resp.header_lower_text);
										}
									}
									if (zipcode_check_compulsory_status == 1 && (localStorage.getItem('pincode_val') === null || localStorage.getItem('pincode_val') === undefined || localStorage.getItem('pincode_val').trim() === '' || localStorage.getItem('pincode_val') === 'null')) {
										$('.modal_popup').show();
										$('.aj-remove.close-popup').css('display','none');
									}
									if (restrict_store_entry_status == 1) {
										$('.modal_popup').show();
										$('.aj-remove.close-popup').css('display','none');
									}	
								}
								localStorage.setItem("is_enabled_checkout",0);	
							}
							
							localStorage.setItem("is_valid_zipcode",is_valid_zipcode);
							if(domain == "www.chickenway.in"){
								if(is_valid_zipcode == 1){
									removeCheckButtonAction('Continue');
									$(".zipcode_submit").addClass('close_pop');
									$(document).on('click',".close_pop",function(event){
										setTimeout(function(){
											if(is_valid_zipcode == 1){
												event.preventDefault();
												$('.modal_popup').hide();
												localStorage.setItem("zipcode_modal_popup",false);
											}
										},1000);
									})
								}else{
									removeCheckButtonAction(button_text);
									$(".zipcode_submit").removeClass('close_pop');
								}
							}else{
								removeCheckButtonAction(button_text);
							}
						}
					},
				error:function(resp){
					removeCheckButtonAction(button_text);
				}
				});
			}
			$('.check-diff-pin').click(function(){
				$('.aj_zipcode_header .message').hide();
				$('.customer_email, .customer_phone, .waiting_list_submit, #change_zipcode, .waiting_list_msg, .hidden-choose-code').hide();
				$(".zipcodecheck_area").slideDown();
				// $('.error_msg').show();
			})
			$($zipcodeInputBoxID).keyup(function(){
				if($($zipcodeInputBoxID).val().trim() == ''){  
					$('.validation_msg .message').css('display','none');
					if(restriction_btn_status == 1){
						if($('.product-form__payment-container').hasClass('custom-pdp-action-btn')){
							$('.custom-pdp-action-btn').addClass('custom-disabled-btn');
						}else{
							$addtocartbtn.attr("disabled", true);
						}
						is_valid_zipcode = 0;
						$addtocartbtn.attr("title",warning_text);
					}
				}
			});	  
			
			(($($zipcodeInputBoxID).val() || '').trim() == '') ? $addtocartbtn.attr("title",warning_text) : $addtocartbtn.removeAttr("title",warning_text);				

			$(document).on('click','[type=radio],.radio-wrapper, .selector-wrapper>select, select',function(){
                var timer_array = [100,200,400,800,1000,2000,4000];
                $.each(timer_array, function( index, timer ) {
                    setTimeout(function () {                        
                        if ($('.validation_msg .error_msg').css('display') == 'none' && $($zipcodeInputBoxID).val() != '') {
                            if ($('.validation_msg .not_valid_error_msg').css('display') != 'none') {
                                $addtocartbtn.attr("disabled", true);
                            } else {
                                $addtocartbtn.removeAttr("disabled");
                            }
                        } else {
                            if (restriction_btn_status == 1 ) {
                            	if(typeof(product_visiblity) != 'undefined'){
                            		if(product_visiblity == 1){
	                            		setTimeout(function() {
	                                    	$addtocartbtn.attr("disabled", true);
		                                }, 100);
				                    }
                            	}else{
			                    	setTimeout(function() {
	                                    $addtocartbtn.attr("disabled", true);
	                                }, 100);
			                    }
                            }
                        }
                        if ($('.validation_msg .success_msg').css('display') == 'none' && $('.validation_msg .error_msg').css('display') == 'none' && $('.validation_msg .not_valid_error_msg').css('display') == 'none' && $($zipcodeInputBoxID).val() != '' ) {
                        	if(typeof(product_visiblity) != 'undefined'){
                            		if(product_visiblity == 1){
		                        		$addtocartbtn.attr("disabled", true);
			                        }
                        	}else{
                        		$addtocartbtn.attr("disabled", true);
                        	} 
                        }
                    },timer);
                });                
            });

			setTimeout(function(){ if($('.contact_details').length > 0){	
				$("#customer_phone").bind("keypress", function (e) {
					var keyCode = e.which ? e.which : e.keyCode		
					if(!((keyCode >= 48 && keyCode <= 57) || keyCode == 43 || keyCode == 32)) {
					  return false;
					}
				});
								
				if(domain == "luftig.no"){
					var phone_number = window.intlTelInput(document.querySelector("#customer_phone"), {
						hiddenInput: "full",
						initialCountry: "no",
						utilsScript: "//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.js"
					  });
				}else if(domain == "sudofoods.com"){					
					var phone_number = window.intlTelInput(document.querySelector("#customer_phone"), {
						hiddenInput: "full",
						onlyCountries:["in"],
						utilsScript: "//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.js"
					  });
				}else{
					var phone_number = window.intlTelInput(document.querySelector("#customer_phone"), {
						hiddenInput: "full",
						utilsScript: "//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.js",
						initialCountry: "auto",
						geoIpLookup: function(success, failure) {
							$.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
								var countryCode = (resp && resp.country) ? resp.country : "us";
								success(countryCode);
							});
						},
					  });
				}
				var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];
				var errorCode = phone_number.getValidationError();    
				var errorMsg = document.querySelector("#invalid_phone");
				var reset = function() {	
					errorMsg.innerHTML = "";
					errorMsg.classList.add("hide");		
				};
				if(waiting_list_btn_status == 1){
					$(document).on('click','.waiting_list_submit',function(event){
						event.preventDefault();
						var zipcode = $($zipcodeInputBoxID).val().trim();
						var customer_email = $('#customer_email').val();
					
						$("#customer_phone").blur(function() {
							reset();	
							if (!phone_number.isValidNumber()) {			
								var errorCode = phone_number.getValidationError();
								if(typeof errorMap[errorCode] == "undefined"){				
									errorMsg.classList.add("hide");
								}else{
									errorMsg.innerHTML = errorMap[errorCode];
									errorMsg.classList.remove("hide");
								}			
							}
						});
						
						var customer_phone = phone_number.getNumber(intlTelInputUtils.numberFormat.E164);
						var device_type = '';   
						(customer_email == '') ? $('#req_email').show() : $('#req_email').hide();
						
						$("#customer_email").keyup(function(){
							if($('#customer_email').val().trim() == ''){
								$('#req_email').show();
								$('#invalid_email').hide();
							}else{
								$('#req_email').hide();
							}
						});		
					
						if(checkEmail($('#customer_email').val().trim()) == false){						
							if(customer_email != ''){			
								$('#invalid_email').show(); 
							}
							is_valid_email = false;
						}else{		
							$('#invalid_email').hide();
							is_valid_email = true;		
						}			
						
						let userAgentString =  navigator.userAgent; 
					
						if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgentString)){
							device_type = "Mobile";
						}else{
							device_type = "Desktop";  
						}    
					
						if(is_valid_email == true){
							$.ajax({
								type : 'post',
								url  : appURL+'/waiting-list',
								data  : { 'zipcode' : zipcode,'customer_email' : customer_email,'customer_phone' : customer_phone, 'domain' : domain, 'product_name' : product_name, 'device_type' : device_type, 'product_id' : product_id, 'product_handle' : product_handle, 'template_name' : template_name},
								dataType : 'json',
								success:function(resp){
									$('#invalid_email').hide();
									if(resp.waiting_list_status == 1){
										$('#customer_email, #customer_phone').val('');
										$('.waiting_success_msg').show();
										setTimeout(function() {
											$('.waiting_success_msg').fadeOut('slow');
										}, 2000);
									}
								},
								error:function(resp){}
							}); 
						}
					});
					$("#customer_phone").on('keyup change', reset);
					function checkEmail(email){
						var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;  
						return regex.test(email);
					}
				}
				$(document).on('click','#change_zipcode',function(event){	
					if (!$('.aj_zipcode_header').is(':empty')) {
						$('.customer_email, .customer_phone, .waiting_list_submit, #change_zipcode, .waiting_list_msg, .hidden-choose-code').hide();
						$('.block_label_text, .aj-input-location-container').slideDown();
						$(".zipcodecheck_area").slideDown();
						$('.aj_auto_detect_location').show();
					}else{
						$('.customer_email, .customer_phone, .waiting_list_submit, #change_zipcode, .waiting_list_msg, .hidden-choose-code').hide();
						$(".zipcodecheck_area").slideDown();
						$('.error_msg').show();
						$('.aj_auto_detect_location').show();
					}
				});
			}}, 2000);
		}
	}else{
		if(zipcode_app_status == '1'){			
			var is_enabled_checkout = localStorage.getItem("is_enabled_checkout");			
			if(enable_checkout_button == 1){									
				if(is_enabled_checkout == '1'){
					$('[name*="'+checkout_btn_selector+'"]').removeAttr("disabled");
					$('.zipcode_checkout_btn_info').remove();
					$('.zipcode_disable_checkout_btn_info').remove();
				}else{
					$('[name*="'+checkout_btn_selector+'"]').attr("disabled", true);
					if($('.zipcode_checkout_info').length > 0){
						$('.zipcode_checkout_info').append('<p class="zipcode_disable_checkout_btn_info">Please enter valid pincode to enable checkout button</p>');
					} else {
						$('form').find('[name*="'+checkout_btn_selector+'"]').parent().before('<p class="zipcode_disable_checkout_btn_info">Please enter valid pincode to enable checkout button</p>');
					}
				}			
				if(zip_prod_config_status != 'all_prod'){
					if(template_name == 'cart'){
						$('[name*="'+checkout_btn_selector+'"]').removeAttr("disabled");
					}
				}	
			}			
		}
	}
	if((location_detection_status && selected_plan != 0) || (selected_plan == 0 && trial_mode == 1)){
		$(document).on('click','#aj_detect_location',function(){
			if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(fetchZipCode, handleError);
			} else {
				console.log("Geolocation is not supported by this browser.");
			}
		});
		function handleError(error) {
			console.error("Geolocation error:", error.message);
		}
		
		function fetchZipCode(position) {
			const lat = position.coords.latitude;
			const lng = position.coords.longitude;
			const geocodeAPI = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${aj_google_map_key}`;
		
			fetch(geocodeAPI)
			.then(response => response.json())
			.then(data => {
				const addressComponents = data.results[0]?.address_components;
				const zipcode = addressComponents?.find(component =>
				component.types.includes("postal_code")
				)?.long_name;
		
				if (zipcode) {
					document.getElementById("zipcode_text").value = zipcode;
					$('.zipcode_submit').click();
				} else {
					console.log("Unable to retrieve the zip code.");
				}
			})
			.catch(error => {
				console.error("Error fetching zip code:", error);
				console.log("Error retrieving location data.");
			});
		}
	}
}

function removeCheckButtonAction(text){
	$('.zipcode_submit').text(text).css({ "opacity": "1", "cursor": 'default' }).prop('disabled', false);
}

if(typeof jQuery == 'undefined'){
  var headTag = document.getElementsByTagName("head")[0];
  var jqTag   = document.createElement('script');
  jqTag.type  = 'text/javascript';
  jqTag.src   = 'https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js';
  jqTag.onload = zipCodeScriptTag;
  headTag.appendChild(jqTag);
}else{
  if(typeof product_id  !="undefined"){	  
    zipCodeScriptTag();
  }
}