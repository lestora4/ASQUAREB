/* ERROR FETCHING: Failed to fetch
   URL: https://cdn.shopify.com/extensions/019ef005-9453-75a0-93c4-a574a75be47c/tazoh-shoppable-video-238/assets/e-BiOdJgv4.js */