/* ERROR FETCHING: Failed to fetch
   URL: https://cdn.shopify.com/extensions/019f03cc-231d-7163-b6cd-33b98ab24e88/judgeme-592/assets/widget_base.js */